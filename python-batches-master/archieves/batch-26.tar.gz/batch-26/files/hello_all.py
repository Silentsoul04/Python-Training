#!/usr/bin/python
import pickle
f = open('my_training.txt')
print "welcome all to our world"
my_train = pickle.load(f)
print type(my_train)
print my_train
