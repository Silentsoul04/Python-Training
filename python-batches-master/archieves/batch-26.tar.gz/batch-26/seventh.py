#!/usr/bin/python
# sys.argv()
# positional parameters

import sys
first_value = int(sys.argv[1])
second_value = int(sys.argv[2])
print first_value + second_value

