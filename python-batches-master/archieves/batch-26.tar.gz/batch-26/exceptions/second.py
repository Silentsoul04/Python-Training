#!/usr/bin/python
# usage: trying to understand exceptions
# try .. except .. else .. finally
# try block : hold the code to run
# except block : what to expect
# else block : what result you are expecting out of try block
# finally block : finally what we want to do at all block levels.
import sys

try:
  my_num1 = int(raw_input("please enter a number 1:"))
  my_num2 = int(raw_input("please enter a number 2:"))
  result = my_num1/my_num2
except (ValueError,ZeroDivisionError):
  print "you hit on this error - check your values and make sure your denominator is not zero"
  sys.exit()
else:
  print result

'''
please enter a number 1:a
Traceback (most recent call last):
  File "first.py", line 4, in <module>
    my_num1 = int(raw_input("please enter a number 1:"))
ValueError: invalid literal for int() with base 10: 'a'

please enter a number 1:4
please enter a number 2:0
Traceback (most recent call last):
  File "first.py", line 6, in <module>
    result = my_num1/my_num2
ZeroDivisionError: integer division or modulo by zero

'''
