import logging
from logging.handlers import SysLogHandler
# creating the logger.
logger = logging.getLogger("disk_log")
logger.setLevel(logging.DEBUG)

# creating the handler
handler = SysLogHandler(address = '/dev/log')
logger.addHandler(handler)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to handler
handler.setFormatter(formatter)

# add ch to logger
logger.addHandler(handler)


disk_size = int(raw_input("please enter the size of the disk"))
if disk_size >=50 and disk_size < 70:
  logger.warning("The disk might get filled up")
elif disk_size > 70 and disk_size < 80:
  logger.error("The disk is getting filled")
else:
  logger.critical("The application is going down")

