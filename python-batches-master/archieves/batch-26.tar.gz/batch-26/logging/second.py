#!/usr/bin/python
# logging.Formatter
# man date
# logging.basicConfig
# time
import logging as l

l.basicConfig(filename='disk_log.txt',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s ',datefmt='%c')

disk_size = int(raw_input("please enter the size of the disk"))
if disk_size >=50 and disk_size < 70:
  l.warning("The disk might get filled up")
elif disk_size > 70 and disk_size < 80:
  l.error("The disk is getting filled")
else:
  l.critical("The application is going down")


