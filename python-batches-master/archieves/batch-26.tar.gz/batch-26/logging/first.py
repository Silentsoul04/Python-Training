#!/usr/bin/python
# logging.Formatter
# man date
# logging.basicConfig
# time
import logging as l

l.basicConfig(filename='my_log.txt',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s ',datefmt='%c')
l.debug("This is an debug message")
l.info("This is an information message")
l.warning("This is an warning message")
l.error("This is an error message")
l.critical("This is an critical message")


