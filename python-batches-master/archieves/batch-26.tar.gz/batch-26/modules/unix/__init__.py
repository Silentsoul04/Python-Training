import lin
import sol
