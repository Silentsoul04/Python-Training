#!/usr/bin/python

def my_sol_first():
  return "my_sol_first"

def my_sol_second():
  return "my_sol_second"

def my_sol_third():
  return "my_sol_third"

def my_sol_fourth():
  return "my_sol_fourth"
