#!/usr/bin/python

def my_sol3_first():
  return "my_sol3_first"

def my_sol3_second():
  return "my_sol3_second"

def my_sol3_third():
  return "my_sol3_third"

def my_sol3_fourth():
  return "my_sol3_fourth"
