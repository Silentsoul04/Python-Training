#!/usr/bin/python

def my_sol4_first():
  return "my_sol4_first"

def my_sol4_second():
  return "my_sol4_second"

def my_sol4_third():
  return "my_sol4_third"

def my_sol4_fourth():
  return "my_sol4_fourth"
