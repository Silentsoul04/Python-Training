#!/usr/bin/python

def my_sol2_first():
  return "my_sol2_first"

def my_sol2_second():
  return "my_sol2_second"

def my_sol2_third():
  return "my_sol2_third"

def my_sol2_fourth():
  return "my_sol2_fourth"
