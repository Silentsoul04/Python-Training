#!/usr/bin/python

def my_lin4_first():
  return "my_lin4_first"

def my_lin4_second():
  return "my_lin4_second"

def my_lin4_third():
  return "my_lin4_third"

def my_lin4_fourth():
  return "my_lin4_fourth"
