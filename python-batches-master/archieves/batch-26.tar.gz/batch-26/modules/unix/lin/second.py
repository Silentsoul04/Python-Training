#!/usr/bin/python

def my_lin2_first():
  return "my_lin2_first"

def my_lin2_second():
  return "my_lin2_second"

def my_lin2_third():
  return "my_lin2_third"

def my_lin2_fourth():
  return "my_lin2_fourth"
