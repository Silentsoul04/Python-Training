#!/usr/bin/python

def my_lin3_first():
  return "my_lin3_first"

def my_lin3_second():
  return "my_lin3_second"

def my_lin3_third():
  return "my_lin3_third"

def my_lin3_fourth():
  return "my_lin3_fourth"
