#!/usr/bin/python

def my_lin_first():
  return "my_lin_first"

def my_lin_second():
  return "my_lin_second"

def my_lin_third():
  return "my_lin_third"

def my_lin_fourth():
  return "my_lin_fourth"
