#!/usr/bin/python
import sys
sys.path.insert(0,'/home/tcloudpython/python-examples/batch-26/modules/extra')
import first as f

def my_add(a,b):
  ''' this is a function for adding numbers'''
  a=int(a)
  b=int(b)
  return a + b
  
if __name__ == '__main__':
  print "addition of two string {}".format(f.my_add('python',' rocks'))
  print "addition of two numbers {}".format(my_add(10,20))
