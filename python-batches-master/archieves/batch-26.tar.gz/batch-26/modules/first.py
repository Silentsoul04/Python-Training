#!/usr/bin/python
# usage: A calculator

version=2.0
def my_add(a,b):
  ''' This is the function for addition of numbers and strings '''
  return a+b
  
def my_div(a,b):
  ''' This is the function for division '''
  return a/b
  
def my_sub(a,b):
  ''' This is the function for substraction '''
  if a > b:
    return a - b
  elif b > a:
    return b - a
    
def my_mul(a,b):
  ''' This is the function for multiplication '''
  return a * b
  
if __name__ == '__main__':
  print "Congo, i learned to write a calculator"

  
	
