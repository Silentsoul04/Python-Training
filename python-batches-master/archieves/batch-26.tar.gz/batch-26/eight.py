#!/usr/bin/python
# usage: A calculator


def my_add(a,b):
  ''' This is the function for addition '''
  return a+b
  
def my_div(a,b):
  ''' This is the function for division '''
  return a/b
  
def my_sub(a,b):
  ''' This is the function for substraction '''
  if a > b:
    return a - b
  elif b > a:
    return b - a
    
def my_mul(a,b):
  ''' This is the function for multiplication '''
  return a * b

  
	
