#!/usr/bin/python
# usage: simulate a useradd command

limiter=":"
name = raw_input("please enter the name:")
my_value = [name,"x","501","501","home directory for"+name,"/home/"+name,"/bin/bash"]
print limiter.join(my_value)
