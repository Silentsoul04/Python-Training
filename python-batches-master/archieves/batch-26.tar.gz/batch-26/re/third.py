#!/usr/bin/python

import re
reg = re.compile('[a-z.]+@[a-z.]+[a-z.]+[a-z]+')
# tuxfux.hlp@yahoo.com
# tuxfux.hlp@yahoo.co.in

f = open('my_email.txt','r')
my_file = f.read()
f.close()

#print my_file

print reg.findall(my_file)


'''
my email address is tuxfux.hlp@
my email address is tuxfux.hlp@gmail
my email address is tuxfux.hlp@gmail.com
my email address is @gmail.com
my email address is tuxfux.hlp@yahoo.com
my email address is tuxfux.hlp@in.com
my email address is tuxfux.hlp@yahoo.co.in
my email address is tuxfux.hlp@yahoo.co.uk
'''
