#!/usr/bin/python
import re

answer = raw_input("do you want to do this(yes/no)")
if re.match('yes',answer,re.I):
  print "welcome to the game"
else:
  print "Not welcome to the game"
