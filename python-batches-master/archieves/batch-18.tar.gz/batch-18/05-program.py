#!/usr/bin/python

print "--- CASE I ---- "
my_value=10

def my_test(my_value):
    print my_value
    my_value=5
    return my_value
    
#print my_test(my_value)
my_value=my_test(my_value)
print "global" , my_value

print "--- CASE II ---- "
my_value=10

def my_test(my_value):
    print my_value
    my_value=5
    print my_value
    
#print my_test(my_value)
my_value=my_test(my_value)
print my_value
