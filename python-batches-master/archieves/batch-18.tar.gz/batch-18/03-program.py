#!/usr/bin/python
# usage: kiosk for fish market

print "welcome to the fish market \n"
my_type = raw_input("please tell what you want(fish/mutton/chicken):")
if my_type == 'fish':
  print "please enter the fish type \n"
  fish_type = raw_input("please enter the fish type (peru,rohu,solomon): \n")
  if fish_type == 'peru':
    print "we have peru fish"
    print "how much quantity you need"
  elif fish_type == 'solomon':
    print "we have solomon fish"
    print "how much quantity you need"
  elif fish_type == 'rohu':
     print "we have the rohu fish"
     print "how much quantity you need"
  else:
    print "sorry!! we dont have your type"
    print "we have vegtable too!!"
    print "please visit us again"
elif my_type == 'mutton':
  pass
elif my_type == 'chicken':
  pass
else:
  pass
  

