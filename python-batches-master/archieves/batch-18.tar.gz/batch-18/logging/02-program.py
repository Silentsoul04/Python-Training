#!/usr/bin/python
# DEBUG,INFO,WARNING,ERROR,CRITICAL - levels - default level - WARNING
# debug,info,warning,error,critical - functions to call the levels
import logging as l
l.basicConfig(filename='new.log',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s',datefmt='%c' )
l.debug("This is debug message")
l.info("This is an information message")
l.warning("this is an warning message")
l.error("This is an error message")
l.critical("This is an critical message")

# use l.Formatter? to get the help for the format options.
# use "man date" for the date options
# handler issues - what about other location or services ?
# logger issue 
