import logging 
from logging.handlers import SysLogHandler

#logger
logger = logging.getLogger("My appy")
# Filter
logger.setLevel(logging.DEBUG)

# handler
handler = SysLogHandler(address = '/dev/log')

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
handler.setFormatter(formatter)
# add handler to logger 
logger.addHandler(handler)

logger.debug("Hello these are debug message")
logger.error("Hello these are error message")
