#!/usr/bin/python
import logging as l
l.info("This is an information message")
l.debug("This is debug message")
l.warning("this is an warning message")
l.error("This is an error message")
l.critical("This is an critical message")
