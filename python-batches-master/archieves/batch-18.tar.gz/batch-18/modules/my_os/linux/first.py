#!/usr/bin/python
def my_first():
  return 'this is my first program'
