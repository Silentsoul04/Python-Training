#!/usr/bin/python
def my_third():
  return "this is the third function"
