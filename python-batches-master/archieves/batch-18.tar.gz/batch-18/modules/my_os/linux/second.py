#!/usr/bin/python
def my_second():
  return 'this is my second function'
