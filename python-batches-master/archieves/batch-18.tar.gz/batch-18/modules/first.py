#!/usr/bin/python

version='2.0'

# this is for addition
def my_add(a,b):
  ''' This is for addition
      syntax: my_add(10,20) '''
  return a+b
  
def my_sub(a,b):
  ''' This is for sub '''
  return a-b

def my_mult(a,b):
  ''' This is for multiplication '''
  return a*b


if __name__ == '__main__':
	print "i am trying to understand maths"
	print "addition of two numbers is" , my_add(2,3)