#!/usr/bin/python
import sys
sys.path.insert(0,'/home/tcloudost/python-examples/batch-18/modules/')
import first

print "addition of two numbers is %d" %(first.my_add(2,3))
print "substartion of two numbers is %d" %(first.my_sub(9,3))

