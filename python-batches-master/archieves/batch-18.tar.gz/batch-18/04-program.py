#!/usr/bin/python
# Usage: Number guessing game
import sys

answer = raw_input("do you want to play the game:(y/n)")
if answer == 'n':
  sys.exit()


# break - kick me out of the loop
number = 7 # rand
#test = True

while True:
  guess_number = int(raw_input("please enter the number:"))
  if number < guess_number:
    print "buddy !!! you entered a larger number"
  elif number > guess_number:
    print "buddy !!! you entered a smaller number"
  elif number == guess_number:
    print "congratulation !!, you have got right number"
    #test=False
    break
   
print "Thanks for playing the game"
print "please visit us again"


