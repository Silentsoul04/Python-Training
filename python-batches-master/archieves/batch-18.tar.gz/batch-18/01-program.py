#!/usr/bin/python
# Author : Santosh D
# date: Feb 13th
# usage: teaching first program of python
# Log: santosh D : Feb 13th : i am putting a new line character.
#  
print "hello World!!! \n"
name = raw_input("please enter your name:\n")
age = int(raw_input("please enter your age:\n"))
gender = raw_input("please enter your gender:\n")

print "name:%s , age:%d , gender:%s" %(name,age,gender)
