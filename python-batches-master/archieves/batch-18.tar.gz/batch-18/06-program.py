#!/usr/bin/python
My_days = ['today','yesterday','tomorrow','dayafter']
#Today
#YEsterday
#TOMorrow
#DAYAfter

for value in My_days:
  print value[:(My_days.index(value) + 1)].upper() + value[(My_days.index(value) + 1):]
