#!/usr/bin/python

my_first_var = 'This is my first variable'

def my_first():
  return 'my first program'

