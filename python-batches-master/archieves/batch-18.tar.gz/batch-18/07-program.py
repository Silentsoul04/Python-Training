#!/usr/bin/python
# usage: exceptions
try:
	num1 = int(raw_input("please enter the number 1:"))
	num2 = int(raw_input("please enter the number 2:"))
	result=num1/num2
except ValueError:
	print "Please enter numbers"
except ZeroDivisionError:
	print "Please don't enter denominator as zero"
else:
	print result