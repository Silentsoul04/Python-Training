#!/usr/bin/python
# Usage: Understanding conditons
# Logical operations: and/or

"""
for the linux guys . create .vimrc in your home directory.

tcloudost@tcloudost-VirtualBox ~ $ pwd
/home/tcloudost
tcloudost@tcloudost-VirtualBox ~ $ cat .vimrc
syntax on
set nu
set tabstop=2
set expandtab
set autoindent
tcloudost@tcloudost-VirtualBox ~ $ 
"""

print "welcome to the market"
food_type = raw_input("please enter your food_type - chicken/mutton/fish/veg :")

if food_type == 'chicken':
  pass
elif food_type == 'mutton':
  pass
elif food_type == 'fish':
  print "welcome to the fish market"
  fish_type = raw_input("what kind of fish you need - solomon/tofu/fillets/rohu :")
  if fish_type == 'solomon' or fish_type == 'Solomon':
    print "your fish {} is available".format(fish_type)
    print "how much quantity of {} you need".format(fish_type)
  elif fish_type == 'tofu':
    print "your fish {} is available".format(fish_type)
    print "how much quantity of {} you need".format(fish_type)
  elif fish_type == 'fillets':
    print "your fish {} is available".format(fish_type)
    print "how much quantity of {} you need".format(fish_type)
  else:
    print "your fish {} is not available".format(fish_type)
    print "how about chicken/mutton/veg/other fishes"     
elif food_type == 'veg':
  pass
else:
  pass

