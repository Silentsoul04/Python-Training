#!/usr/bin/python
def divide_one_by(division):
  return 1/division
if __name__ == '__main__':
  divide_one_by(0)
