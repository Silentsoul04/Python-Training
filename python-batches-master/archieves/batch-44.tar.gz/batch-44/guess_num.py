#!/usr/bin/python
# Usage: while loop.
# break : come out of the loop in a nice way.
# sys.exit  : to out of the program.

import sys

yn = raw_input("do you want to exit the game:(y/n)")
if yn == 'y':
  sys.exit()

number=7
#test=True

print "welcome to the number guessing game"

while True:
  guess_num = int(raw_input("please enter a number:"))
  if guess_num > number:
    print "buddy !! you guessed a larger number"
  elif guess_num < number:
    print "buddy !! you guessed a smaller number"
  elif guess_num == number:
    print "Congo!! you guessed the right number"
    #test=False
    break
    
print "Please visit us again"
  
