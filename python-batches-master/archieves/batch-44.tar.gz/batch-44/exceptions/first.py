#!/usr/bin/python
# try .. except .. else .. finally
# try - computation
# except - exceptions
# else - activate the block if compuation is good.
# finally -
# case 1 : Enter valid values - try .. else .. finally.
# case 2 : Enter invalid values - program handling exceptions - try .. except .. finally
# case 3 : Enter invalid values - program not handling exceptions - try .. finally .. bombed out.

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  result = num1/num2
except ValueError,error:
  print "please enter numbers."
  print error
except ZeroDivisionError,error:
  print "make sure your denominator is non-zero"
  print error
else:
  print "the result {}".format(result)
finally:
  print "We have finally made it"


'''
# example 5

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  result = num1/num2
except ValueError,error:
  print "please enter numbers."
  print error
except ZeroDivisionError,error:
  print "make sure your denominator is non-zero"
  print error
else:
  print "the result {}".format(result)
finally:
  print "We have finally made it"

# example 4

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  result = num1/num2
except ValueError:
  print "please enter numbers."
else:
  print "the result {}".format(result)
finally:
  print "We have finally made it"

# example 3

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  result = num1/num2
except ValueError:
  print "please enter numbers."
except ZeroDivisionError:
  print "make sure your denominator is non-zero"
else:
  print "the result {}".format(result)

# example 2:

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  result = num1/num2
except (ValueError,ZeroDivisionError):
  print "please enter numbers .. make sure denominator is non-zero"
else:
  print "the result {}".format(result)

# example 1:
try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  result = num1/num2
except:
  print "please enter numbers .. make sure denominator is non-zero"
else:
  print "the result {}".format(result)

'''
