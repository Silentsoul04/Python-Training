#!/usr/bin/python

def my_first_sol1():
  return "This is my first sol1 function"

def my_second_sol1():
  return "This is my second sol1() function"

def my_third_sol1():
  return "This is my third sol1() function"
