#!/usr/bin/python

def my_first_sol3():
  return "This is my first sol3 function"

def my_second_sol3():
  return "This is my second sol3() function"

def my_third_sol3():
  return "This is my third sol3() function"
