#!/usr/bin/python

def my_first_sol2():
  return "This is my first sol2 function"

def my_second_sol2():
  return "This is my second sol2() function"

def my_third_sol2():
  return "This is my third sol2() function"
