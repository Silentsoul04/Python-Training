#!/usr/bin/python

def my_first_sol4():
  return "This is my first sol4 function"

def my_second_sol4():
  return "This is my second sol4() function"

def my_third_sol4():
  return "This is my third sol4() function"
