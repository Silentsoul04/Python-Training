#!/usr/bin/python

def my_first_lin3():
  return "This is my first lin3 function"

def my_second_lin3():
  return "This is my second lin3() function"

def my_third_lin3():
  return "This is my third lin3() function"
