#!/usr/bin/python

def my_first_lin1():
  return "This is my first lin1 function"

def my_second_lin1():
  return "This is my second lin1() function"

def my_third_lin1():
  return "This is my third lin1() function"
