#!/usr/bin/python

def my_first_lin2():
  return "This is my first lin2 function"

def my_second_lin2():
  return "This is my second lin2() function"

def my_third_lin2():
  return "This is my third lin2() function"
