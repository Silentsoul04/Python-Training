#!/usr/bin/python

def my_first_lin4():
  return "This is my first lin4 function"

def my_second_lin4():
  return "This is my second lin4() function"

def my_third_lin4():
  return "This is my third lin4() function"
