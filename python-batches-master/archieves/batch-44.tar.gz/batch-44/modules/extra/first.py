#!/usr/bin/python

version = 2.0


def my_add(a,b):
  ''' This is the addition of two numbers/string '''
  return a + b
  
def my_sub(a,b):
  """ This is the substraction of two number """
  if a > b:
    return a - b
  elif b > a:
    return b - a

# Main program 
if __name__ == '__main__':
  print "get set go .. missile launced"
    

