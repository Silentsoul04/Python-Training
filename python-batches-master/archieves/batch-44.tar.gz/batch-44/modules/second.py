#!/usr/bin/python
import sys
sys.path.insert(0,'/home/tcloudost/python-examples/batch-45/modules/extra')

import first as f

def my_add(a,b):
  ''' this is only for addition of floats'''
  a = float(a)
  b = float(b)
  return a + b
  
# Main program
print "addition of two floats is {}".format(my_add(1,2))
print "addition of two strings is {}".format(f.my_add('linux','rocks'))


'''
top
 + dir1
    + script1
    + script2
    + script3
    + script4
 + dir2
    + script1
    + script2
    + script3
    + script4

'''
