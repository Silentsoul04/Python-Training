#!/usr/bin/python
# Inheritace
# movies

class InvalidAgeException(Exception):
  def __init__(self,age):
    self.age = age
    
def validate_age(age):
  if age >= 18:
    return "Buddy you have grown enough !!!"
  else:
    raise InvalidAgeException(age)
    
# Main Program
age = int(raw_input('please enter the age:'))

try:
  validate_age(age)
except InvalidAgeException as e:
  print "buddy!!! you still a kiddo at {}".format(e.age)
else:
  print validate_age(age)
    



