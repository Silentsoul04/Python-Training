#!/usr/bin/python

class  banking:         # Parent
  def __init__(self):   # constructor - first method
    self.__balance=0
  def deposit(self,amount):                    # method
    self.__balance=self.__balance + amount
    return self.__balance
  def withdraw(self,amount):
    self.__balance=self.__balance - amount
    return self.__balance
    
class MinBalanceAccount(banking):  # child
  def __init__(self):
    banking.__init__(self)
  def withdraw(self,amount):
    if self.__balance - amount < 1000:
      print "buddy!!! We have to maintain minimum 1000..call your friend"
    else:
      banking.withdraw(self,amount)
      

