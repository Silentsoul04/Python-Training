#!/usr/bin/python

def balance():
  return {'balance':0}
  
def deposit(name,amount):
  name['balance'] = name['balance'] + amount
  return name['balance']
  
def withdraw(name,amount):
  name['balance'] = name['balance'] - amount
  return name['balance']
  
# Working with money

siva = balance()
print "Initial balance of siva {}".format(siva['balance'])
deposit(siva,1000)
withdraw(siva,300)
print "Balance of siva {}".format(siva['balance'])

rajni = balance()
print "Initial balance of rajni {}".format(rajni['balance'])
deposit(rajni,1000)
withdraw(rajni,500)
print "Balance of rajni {}".format(rajni['balance'])

