#!/usr/bin/python

class  banking:         # Parent
  def __init__(self):   # constructor - first method
    self.balance=0
  def deposit(self,amount):                    # method
    self.balance=self.balance + amount
    return self.balance
  def withdraw(self,amount):
    self.balance=self.balance - amount
    return self.balance
    
class MinBalanceAccount(banking):  # child
  def __init__(self):
    banking.__init__(self)
  def withdraw(self,amount):
    if self.balance - amount < 1000:
      print "buddy!!! We have to maintain minimum 1000..call your friend"
    else:
      banking.withdraw(self,amount)
      
# Rajni - college boy
Rajni = MinBalanceAccount()
print dir(Rajni)
Rajni.balance=2000
Rajni.withdraw(1100)
print Rajni.balance

# rajesh - working boy
Rajesh = banking()
Rajesh.balance=2000
Rajesh.withdraw(1100)
print Rajesh.balance
