#!/usr/bin/python

class  banking:
  balance=0
  def deposit(self,amount):
    self.balance=self.balance + amount
    return self.balance
  def withdraw(self,amount):
    self.balance=self.balance - amount
    return self.balance
    
rajesh = banking()
print rajesh.deposit(10000)
print rajesh.withdraw(200)
print rajesh.balance

sai = banking()
print sai.deposit(2000)
print sai.withdraw(200)
print sai.balance
