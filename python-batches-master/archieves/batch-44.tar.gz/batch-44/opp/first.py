#!/usr/bin/python

balance=0

def deposit(amount):
  global balance
  balance = balance + amount
  return balance
  
def withdraw(amount):
  global balance
  balance = balance - amount
  return balance

print "Initially balance {}".format(balance) 
deposit(1000)
print "after 1000 - balance {}".format(balance)
withdraw(200)
print "after 200 - balance {}".format(balance)

