#!/usr/bin/python
import cProfile
import pstats
import glob
import math

def gen():
    result=[]
    for i in range(1, 10):
        result.append(math.factorial(i))
    return result

class index(object):
    def GET(self):
        p = cProfile.Profile()

        it = gen()
        while True:
            try:
                nxt = p.runcall(next, it)
            except StopIteration:
                break
            print nxt

        p.print_stats()

index().GET()
