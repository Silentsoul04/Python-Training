#!/usr/bin/python

class  banking:
  def __init__(self,balance):   # constructor - first method
    self.balance=balance
  def deposit(self,amount):                    # method
    self.balance=self.balance + amount
    return self.balance
  def withdraw(self,amount):
    self.balance=self.balance - amount
    return self.balance
    
raghu = banking(balance=1000)
print raghu.balance
raghu.deposit(1000)
print "balance {}".format(raghu.balance)
