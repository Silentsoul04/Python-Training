#!/usr/bin/python
# http://simeonfranklin.com/blog/2012/jul/1/python-decorators-in-12-steps/

def outer(func):
  def inner(*args,**kwargs):
    try:
      func(*args)
    except Exception as e:
      return 'our exception is - {}'.format(e)
    else:
      return func(*args)
  return inner
      
@outer
def div(a,b):
  return a/b

@outer  
def add(a,b):
  return a + b   


#print div(10,2)
#print add(1,2)
#print add('1',2)
#print div(10,0)

# or the below one

'''
# calling the decorators
my_new = outer(div)
print my_new
print my_new(10,0)
print my_new(10,2)


def div(a,b):
  try:
    a/b
  except Exception as e:
    return 'our exception is - {}'.format(e)
  else:
    return a/b
    
def add(a,b):
  try:
    a + b
  except Exception as e:
    return 'our exception is - {}'.format(e)
  else:    
    return a + b

'''
