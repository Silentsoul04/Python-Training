#!/usr/bin/python

from excel import OpenExcel 
f = OpenExcel('names.xls') 
print f.read('A')
print f.read('B')
print "{} is a {}".format(f.read('A6'),f.read('B6'))
