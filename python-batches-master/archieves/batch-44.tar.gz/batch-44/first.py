#!/usr/bin/python
print ("hello world")

"""
tcloudost@tcloudost-VirtualBox ~ $ ls
Anaconda2-2.5.0-Linux-x86_64.sh  f2.txt         Projects              SV.anaconda2
class3.ipynb                     file1.text     Public                tcloudpython-Home.tar.gz
clinet.py                        folder1        puppet-labs           Templates
Desktop                          helloworld.py  pycharm-edu-2.0       Test
Django-examples                  local.py       pycharm-edu-2.tar.gz  Untitled0.ipynb
Documents                        Music          PycharmProjects       Untitled1.ipynb
Downloads                        new.sh         python-examples       Videos
example.xlsx                     Pictures       server.py             while.py
tcloudost@tcloudost-VirtualBox ~ $ cd python-examples/
tcloudost@tcloudost-VirtualBox ~/python-examples $ cd batch-44
tcloudost@tcloudost-VirtualBox ~/python-examples/batch-44 $ ls
batch44.txt  first.py  help_notest.txt  Installation.txt  opensource.txt  variables_notes.txt
tcloudost@tcloudost-VirtualBox ~/python-examples/batch-44 $ 
tcloudost@tcloudost-VirtualBox ~/python-examples/batch-44 $ python first.py
hello world
tcloudost@tcloudost-VirtualBox ~/python-examples/batch-44 $ 

"""
