#!/usr/bin/python
# l.basicConfig?
# l.Formatter?
# man date # man page of date - windows

import logging as l
l.basicConfig(filename='myapp.log',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s ',datefmt='%c')

l.debug("This is a debug message")
l.info("This is an informational message")
l.warning("This is a warning message")
l.error("This is an error message")
l.critical("This is a critical message")
