#!/usr/bin/python
# Default level is warning
import logging as l
l.debug("This is a debug message")
l.info("This is an informational message")
l.warning("This is a warning message")
l.error("This is an error message")
l.critical("This is a critical message")

