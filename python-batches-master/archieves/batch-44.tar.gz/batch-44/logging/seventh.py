#!/usr/bin/python
# example of FileHandler
# l.basicConfig?
# l.Formatter?
# man date # man page of date - windows
# references:
# https://docs.python.org/2/howto/logging.html
# https://docs.python.org/2/howto/logging-cookbook.html

# understanding the advanced stuff
# logger - root
# Handlers - ex: filename='diskapp.log'
# Filters - ex: level=l.DEBUG
# Formatters - ex : format='%(asctime)s - %(levelname)s - %(name)s - %(message)s '

import logging
from subprocess import PIPE,Popen
import re
from logging.handlers import SysLogHandler

#l.basicConfig(filename='diskapp.log',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s ',datefmt='%c')

## -- Advanced Logging --- ## 

# create logger
logger = logging.getLogger('disk check')   # Logger
logger.setLevel(logging.DEBUG)             # filter

# create console handler and set level to debug
ch = SysLogHandler(address="/dev/log")               # Handler - console output
ch.setLevel(logging.DEBUG)                 # filter

# create formatter
formatter = logging.Formatter(' %(name)s - %(levelname)s - %(message)s')  # Formatter

# add formatter to ch
ch.setFormatter(formatter)  # club together handler and formatter

# add ch to logger
logger.addHandler(ch)       # club together the handler and logger.

# scanning your disk.
# disk_size = $(df -h /|tail -n 1|awk '{print $5}'|sed -e 's#%##'g)

#disk_size = int(raw_input("please enter the disk size:"))
p1 = Popen(["df","-h","/"], stdout=PIPE)
p2 = Popen(["tail","-n","1"],stdin=p1.stdout,stdout=PIPE)
output=p2.communicate()[0]
disk_size = int(re.search('([0-9]+)%',output).group(1))

if disk_size <= 60:
  logger.info("The disk is going healthy.")
elif disk_size >60 and disk_size <=75:
  logger.warning("The disk seems to be getting filled up.")
elif disk_size >75 and disk_size <=85:
  logger.error("Buddy!! one of the disk is filled up.")
elif disk_size > 85:
  logger.critical("Buddy!! you application is sleeping.")

