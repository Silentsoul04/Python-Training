#!/usr/bin/python
# l.basicConfig?
# l.Formatter?
# man date # man page of date - windows

import logging as l
l.basicConfig(filename='diskapp.log',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s ',datefmt='%c')

# scanning your disk.

disk_size = int(raw_input("please enter the disk size:"))

if disk_size <= 60:
  l.info("The disk is going healthy.")
elif disk_size >60 and disk_size <=75:
  l.warning("The disk seems to be getting filled up.")
elif disk_size >75 and disk_size <=85:
  l.error("Buddy!! one of the disk is filled up.")
elif disk_size > 85:
  l.critical("Buddy!! you application is sleeping.")
