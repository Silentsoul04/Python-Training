#!/usr/bin/python
# continue : skipping an iteration

absentee = ['kumar','rajesh','priya']
for student in ['siva','kumar','satish','rajesh','siddharth','vijay','sandeep','priya']:
  if student in absentee:
    continue
    #break
    #pass
  print "report card for {}.".format(student)
