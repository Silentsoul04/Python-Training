#!/usr/bin/python
name = raw_input("please enter your name:")
age = raw_input("please enter your age:")
print "my name is {} and my age is {}".format(name,age)
