#!/usr/bin/python
import re
f = open('myemail.txt','r')
emails = f.read()
f.close()

print emails
print re.findall('[a-z0-9.]+@[a-z.]+',emails,re.I)
