#!/usr/bin/python
import re
answer = raw_input("do you really want to play the game - yes/no :")
if re.match(answer,'yes',re.I):
  print "welcome to the game"
else:
  print "Please visit us later"
