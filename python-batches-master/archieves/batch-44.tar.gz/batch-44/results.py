#!/usr/bin/python
# continue : skipping an iteration

for student in 'siva','kumar','satish','rajesh':
  if student == 'kumar':
    continue
    #break
    #pass
  print "report card for {}.".format(student)
