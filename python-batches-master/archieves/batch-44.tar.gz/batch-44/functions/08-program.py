#!/usr/bin/python
# in python the argumnets are passwd as objects, not as values or references.

def add(a,b):
  return a + b
  
def sub(a,b):
  return a - b
  
def mynew(func,x,y):
  return func(x,y)
  
print type(add) # object functions
print type(sub) # object functions

print mynew(add,12,14)
print mynew(sub,12,14)

