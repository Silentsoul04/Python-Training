#!/usr/bin/python
# case 1: every function has return value. If there is no value it get None.
# case 2: return marks the end of the function.
# case 3: function is a function type.
# case 4: the label of the function gives the address of the function.

def my_func():
  return "hello world"
  
print my_func()       # calling the function.
print my_func         # label of the function.
print type(my_func)   # function type
print type(my_func()) # str type
