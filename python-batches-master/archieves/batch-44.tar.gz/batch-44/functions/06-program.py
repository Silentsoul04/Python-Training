#!/usr/bin/python
# passing arguments
# *,**,*args,*kwargs

# **kwargs

def callme(**kwargs):
  if 'name' in kwargs:
    print "name is {}".format(kwargs['name'])
  if 'age' in kwargs:
    print "age is {}".format(kwargs['age'])
  if 'gender' in kwargs:
    print "gender is {}".format(kwargs['gender'])
  return ''
  
print callme(name='kumari',age=21)
#print callme(age=21,gender='f')


# *args

def gmax(*args):
  big = 0
  for value in args:
    if big < value:
      big = value
  return big
  
print gmax(1,12,63,4)


def my_func(a,b):
  return a + b
  
# list of values
my_list = [11,22]

print my_func(*my_list)  # unpacking


## **

my_dict = {'c':12,'a':11}
print my_func(**my_dict)


