#!/usr/bin/python
# funcation closures

def outer():
  a = 1
  def inner():
    return a
  return inner
  
  
# first we have to call outer
# outer will def inner

mynew =  outer()
print type(mynew)
print mynew
print mynew()

