#!/usr/bin/python
# map,filter,lambda

'''
In [4]: map?
Type:       builtin_function_or_method
String Form:<built-in function map>
Namespace:  Python builtin
Docstring:
map(function, sequence[, sequence, ...]) -> list

Return a list of the results of applying the function to the items of
the argument sequence(s).  If more than one sequence is given, the
function is called with an argument list consisting of the corresponding
item of each sequence, substituting None for missing values when not all
sequences have the same length.  If the function is None, return a list of
the items of the sequence (or a list of tuples if more than one sequence).


In [6]: filter?
Type:       builtin_function_or_method
String Form:<built-in function filter>
Namespace:  Python builtin
Docstring:
filter(function or None, sequence) -> list, tuple, or string

Return those items of sequence for which function(item) is true.  If
function is None, return the items that are true.  If sequence is a tuple
or string, return the same type, else return a list.

# lambda : creation of nameless functions
'''


def square(a):
  return a * a
  
def even(a):
  if a % 2 == 0:
    return 'even'
  
print map(square,range(1,11)) # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
print filter(square,range(1,11)) # [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]  
print filter(even,range(1,11))  # [2, 4, 6, 8, 10]
print map(even,range(1,11))   # [None, 'even', None, 'even', None, 'even', None, 'even', None, 'even']

# Lambda examples
print map(lambda a:a*a,range(1,11)) # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100
print filter(lambda a:a%2 == 0,range(1,11)) # [2, 4, 6, 8, 10]




