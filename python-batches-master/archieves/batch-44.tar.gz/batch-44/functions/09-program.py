#!/usr/bin/python

def outer():
  def inner():
    a = 1
    return a
  return inner()
  
  
# first we have to call outer
# outer will def inner

print outer() # 1
print inner()
