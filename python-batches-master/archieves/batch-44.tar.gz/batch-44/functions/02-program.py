#!/usr/bin/python
# case 1: every function has return value. If there is no value it get None.
# case 2: return marks the end of the function.
# case 3: function is a function type.
# case 4: the label of the function gives the address of the function.
# case 5: Lifespan of a variable inside a function is during the lifespan of the function.
# case 6: variables inside the function are called as local variables.
# case 7: locals() is a function to show you the local namespace(variabels) created inside a function.
# case 8: globals() is a function to show you the global  namespace(variabels).

var = 10           # global value

def my_func():
  print locals()
  var = 1          # local value
  print locals()
  return var
  
print my_func()
print globals()
print var
