#!/usr/bin/python
# case 1: every function has return value. If there is no value it get None.
# case 2: return marks the end of the function.
# case 3: function is a function type.
# case 4: the label of the function gives the address of the function.
# case 5: Lifespan of a variable inside a function is during the lifespan of the function.
# case 6: variables inside the function are called as local variables.
# case 7: locals() is a function to show you the local namespace(variabels) created inside a function.
# case 8: globals() is a function to show you the global  namespace(variabels).
# case 9: local variables are given higher precedence than global variables.
# case 10: If there are no local variables the scope resolution happens from global scope.
# case 11: global keyword can work on global scope.

balance = 0           # global value

def deposit():
  global balance
  print locals()    # {}
  #var = 1          # local value
  #print locals()
  balance = balance + 1000
  return balance
  
def withdraw():
  global balance
  print locals()    # {}
  #var = 1          # local value
  #print locals()
  balance = balance - 300
  return balance

print globals()
print deposit() # balance = 1000
print globals()
print deposit() # balance = 2000
print globals()
print withdraw()
  

