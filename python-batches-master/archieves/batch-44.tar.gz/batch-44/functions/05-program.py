#!/usr/bin/python
# Functional arguments


def my_func(a,b):
  print locals()
  return a + b

def my_new(a,b=1): # b is a default value.
  return a/b
  
# def putty(hostname,port=22)
# putty(hostname,23)
# putty(hostname)

  
print my_func('linux',' rocks')
print my_func(b=' rocks',a='linux')
print my_new(4,2)
print my_new(4)


  

