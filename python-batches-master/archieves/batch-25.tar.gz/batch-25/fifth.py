#!/usr/bin/python
# continue

for student in ('lakshmi','naren','kumar','praveen','monika'):
  if student == 'kumar':
    #continue
    #break
    pass
  print "the report card for %s" %(student)
