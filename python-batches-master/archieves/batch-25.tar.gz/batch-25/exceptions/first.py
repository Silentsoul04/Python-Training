#!/usr/bin/python
# usage: exceptions
# try .. except .. else .. finally
# try: for the code which you are testing
# TODO : exception on except fails :(
import exceptions
import sys

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  results = num1/num2
except ZeroDivisionError as exception:
  print type(exception).__name__
  print "Please enter the numbers"
  sys.exit()
print results
