#!/usr/bin/python
# usage: exceptions
# try .. except .. else .. finally
# try: for the code which you are testing
# except : for the exceptions handling
# else: for your output
# finally:
# case I: try .. else .. finally - if i am giving correct values.
# case II: try .. except .. finally - if i am hitting on an known exception
# case III : try .. finally .. exception - if i am hitting on an unknown exception
# raise : raising your exceptions

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  results = num1/num2
except (ValueError):
  print "Please enter the numbers and don't make your denominator zero"
else:
  print results
finally:
  print "hello .. I am here"
