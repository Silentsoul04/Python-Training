#!/usr/bin/python
import pickle as p
f = open('training.txt')
my_new = p.load(f)
print type(my_new)
print "welcome to cloud"
for value in my_new:
  print "program:{}".format(value)
