#!/usr/bin/python
import pickle as p
training=['perl','python','linux','mysql','cloud']
f = open('training.txt','w')
p.dump(training,f)
f.close()
