#!/usr/bin/python

import logging
from logging.handlers import SysLogHandler

# my logger
logger = logging.getLogger("My appy")
logger.setLevel(logging.DEBUG)

# my handlers
handler = SysLogHandler(address = '/dev/log')

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
handler.setFormatter(formatter)

# add ch to logger
logger.addHandler(handler)

disk_size = int(raw_input("please enter the disk size:"))

if disk_size > 50 and disk_size < 70:
  logger.warning("This is an warning message")
elif disk_size > 70 and disk_size < 90:
  logger.error("This is an error message")
elif disk_size > 90:
  logger.critical("This is an critical message")


