#!/usr/bin/python
# basicConfig
# Formatter
# man date
import logging as l
l.basicConfig(filename='my_appy.log',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',datefmt='%c')
l.debug("This is an debug information")
l.info("This is an info information")
l.warning("This is an warning message")
l.error("This is an error message")
l.critical("This is an critical message")
