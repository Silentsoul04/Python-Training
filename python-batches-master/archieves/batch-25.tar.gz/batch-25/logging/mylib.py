import logging

def do_something():
    logging.info('Doing something')

#print do_something()
