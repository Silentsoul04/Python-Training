#!/usr/bin/python
import logging as l
l.debug("This is an debug information")
l.info("This is an info information")
l.warning("This is an warning message")
l.error("This is an error message")
l.critical("This is an critical message")
