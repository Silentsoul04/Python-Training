#!/usr/bin/python
import logging as l
l.basicConfig(filename='my_disk.log',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',datefmt='%c')
disk_size = int(raw_input("please give the disk size:"))
if disk_size > 50 and disk_size < 70:
  l.warning("This is an warning message")
elif disk_size > 70 and disk_size < 90:
  l.error("This is an error message")
elif disk_size > 90:
  l.critical("This is an critical message")
