#!/usr/bin/python
# usage: market kiosk
# or/and operators

print "Welcome to the market"
type_food = raw_input("please enter the type you want(veg/fish/mutton/chicken):")

if type_food == 'veg':
  pass
elif type_food == 'fish':
  print "welcome to the fish market"
  fish_type = raw_input("please enter the fish type(toffu,solomon,rohu):")
  if fish_type == 'toffu':
    print "how much quantity you need for %s" %(fish_type)
    print "Do you want anyother item"
    print "Please visit us again"
  elif fish_type == 'solomon' or fish_type == 'Solomon':
     print "how much quantity you need for %s" %(fish_type)
     print "do you want anytother item"
     print "please visit us again"
  else:
    print "sorry!! we dont have your fish type %s" %(fish_type)
    print "do you want to buy any other item"
    print "please visit us again"
elif type_food == 'mutton':
  pass
elif type_food == 'chicken':
  pass
else:
  pass
