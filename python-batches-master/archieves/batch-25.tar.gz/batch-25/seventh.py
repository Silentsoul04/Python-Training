#!/usr/bin/python
# kumar,lakshmi who are absent

absent = ['kumar','lakshmi']
for student in ('lakshmi','naren','kumar','praveen','monika'):
  if student in absent:
    continue
    #break
    #pass
  print "the report card for %s" %(student)

# in
