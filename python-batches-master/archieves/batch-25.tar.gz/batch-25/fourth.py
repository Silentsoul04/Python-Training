#!/usr/bin/python
#usage: understanding while loop
# break,sys.exit
import sys

answer = raw_input("do you want to play the game:")
if answer == 'n':
  sys.exit()

number=7
#test=True

while True:
  guess = int(raw_input("please enter the number:"))
  if guess > number:
    print "Buddy !!! the number you guessed is sligtly larger"
  elif guess < number:
    print "Buddy !!! the number you guessed is slightly smaller"
  else:
    print "Congo !!! you got it"
    print "Sorry no choclates for guessing"
    #test=False
    break
    
print "Thanks for playing the game"
