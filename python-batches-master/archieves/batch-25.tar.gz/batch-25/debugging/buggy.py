#!/usr/bin/python

import pdb
pdb.set_trace()
a = int(raw_input("please enter the value 1:"))
b = int(raw_input("please enter the value 2:"))
print a/b
