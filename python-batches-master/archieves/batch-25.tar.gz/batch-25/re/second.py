#!/usr/bin/python

import re
reg = re.compile('^#')

f = open('new.txt','r')
my_file = list(f)
f.close()

#print my_file

for value in my_file:
  if reg.match(value):
    pass
  else:
    print value
