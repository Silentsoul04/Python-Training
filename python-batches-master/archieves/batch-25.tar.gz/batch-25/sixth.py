#!/usr/bin/python
user = raw_input("please enter the username:")
my_details=[user,'x','1001','1001','user dir '+user,'/home/'+user,'/bin/bash']
limiter=':'
print limiter.join(my_details)
