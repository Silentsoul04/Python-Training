#!/usr/bin/python
# usage: sys.argv
import sys

print sys.argv
