#!/usr/bin/python
from sys import path
path.insert(0,'/home/tcloudpython/python-examples/batch-25-latest/modules/extra')
import first

def my_add(a,b):
  a=int(a)
  b=int(b)
  return a + b
  
print "addition of two string is {}".format(first.my_add('python',' rocks'))
print "addition of two numbers is {}".format(my_add('1','1'))
