#!/usr/bin/python

version=3.0

def my_add(a,b):
  ''' syntax:my_add(2,3)
      please enter numbers only '''
  return a + b

def my_sub(a,b):
  if a > b:
    return a - b
  else:
    return b - a
 
def my_mult(a,b):
  return a * b
  
def my_div(a,b):
  return a/b

if __name__ == '__main__':
  print "welcome to the calculator programme"
