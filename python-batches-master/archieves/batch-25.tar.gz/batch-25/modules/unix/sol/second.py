#!/usr/bin/python
def my_sol2_first():
  return "This is my first function"

def my_sol2_second():
  return "This is my second function"

def my_sol2_third():
  return "This is my third function"

def my_sol2_fourth():
  return "this is my fourth function"
