#!/usr/bin/python
def my_lin3_first():
  return "This is my first function"

def my_lin3_second():
  return "This is my second function"

def my_lin3_third():
  return "This is my third function"

def my_lin3_fourth():
  return "this is my fourth function"
