#!/usr/bin/python
def my_lin1_first():
  return "This is my first function"

def my_lin1_second():
  return "This is my second function"

def my_lin1_third():
  return "This is my third function"

def my_lin1_fourth():
  return "this is my fourth function"
