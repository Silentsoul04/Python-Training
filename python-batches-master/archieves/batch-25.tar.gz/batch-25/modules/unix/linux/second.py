#!/usr/bin/python
def my_lin2_first():
  return "This is my first function"

def my_lin2_second():
  return "This is my second function"

def my_lin2_third():
  return "This is my third function"

def my_lin2_fourth():
  return "this is my fourth function"
