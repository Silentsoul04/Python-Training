#!/usr/bin/python
import sys
if len(sys.argv) != 2:
  print "syntax ./{} username".format(sys.argv[0])
  sys.exit(0)
user=sys.argv[1]
#user = raw_input("please enter the username:")
my_details=[user,'x','1001','1001','user dir '+user,'/home/'+user,'/bin/bash']
limiter=':'
print limiter.join(my_details)
